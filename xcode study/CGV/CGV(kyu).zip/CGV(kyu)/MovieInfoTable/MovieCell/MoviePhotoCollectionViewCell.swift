//
//  MoviePhotoCollectionViewCell.swift
//  LoginView
//
//  Created by Maru on 29/11/2018.
//  Copyright © 2018 Maru. All rights reserved.
//

import UIKit

class MoviePhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var moviePhotoImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
