//
//  InsideCollectionViewCell.swift
//  LoginView
//
//  Created by Maru on 13/11/2018.
//  Copyright © 2018 Maru. All rights reserved.
//

import UIKit

class InsideCollectionViewCell: UICollectionViewCell {
    
}
