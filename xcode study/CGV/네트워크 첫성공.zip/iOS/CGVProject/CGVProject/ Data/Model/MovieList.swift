//
//  MovieList.swift
//  CGVProject
//
//  Created by Wi on 04/12/2018.
//  Copyright © 2018 Wi. All rights reserved.
//

import Foundation

class MovieList {
    var movieList: [Movie]?

    
//    private func loadData(){
//        MovieManager.singleton.loadMovieList { movies in
//            print(movies)
//            DispatchQueue.main.async {
//                self.movieList = movies
//            }
//        }
//    }
}
