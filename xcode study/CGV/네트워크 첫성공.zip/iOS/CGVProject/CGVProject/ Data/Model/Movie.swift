//
//  Movie.swift
//  CGVProject
//
//  Created by Wi on 03/12/2018.
//  Copyright © 2018 Wi. All rights reserved.
//

import Foundation


struct Movie: Codable{
    let pk: Int?
    let title: String?
    let reservationScore: Int?
    let mainImgUrl: String?
    let nowShow: Bool?
    let openingDate: String?
    
    enum Codingkeys: String,CodingKey {
        case pk
        case title
        case reservationScore = "reservation_score"
        case mainImgUrl = "main_img_url"
        case nowShow = "now_show"
        case openingDate = "opening_date"
    }
    
}
