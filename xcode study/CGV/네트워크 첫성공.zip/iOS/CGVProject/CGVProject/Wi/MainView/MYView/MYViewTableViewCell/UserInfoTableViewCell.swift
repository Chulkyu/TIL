//
//  UserInfoTableViewCell.swift
//  CGVProject
//
//  Created by Wi on 29/11/2018.
//  Copyright © 2018 Wi. All rights reserved.
//

import UIKit

class UserInfoTableViewCell: UITableViewCell {
    @IBOutlet weak var userProfileImageView: UIImageView!
    @IBOutlet weak var userNickName: UILabel!
    @IBOutlet weak var userID: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }
    func configure(){
        // MARK: userProfileImageView
        
        userProfileImageView.layer.cornerRadius = userProfileImageView.frame.width / 2
        
        // MARK: userID
        userIDEncryption()
    }
    func userIDEncryption(){
        guard var id = userID.text else {return}
        id.remove(at: String.Index(encodedOffset: 2))
        id.append(Character("*"))
        userID.text = id
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
