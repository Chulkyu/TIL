//
//  MovieCollectionViewCellModel.swift
//  CGVProject
//
//  Created by Wi on 03/12/2018.
//  Copyright © 2018 Wi. All rights reserved.
//

import Foundation
class MovieCollectionViewCellModel {
    var moviePosterImage: UIImage?
    var movieName: String
    var movieRank: String
    var advanceRate: String?

    init(_ movie: Movie) {
//        moviePosterImage = UIImage(data: try! Data(contentsOf: URL(string: movie.mainImgUrl)!))!
        movieName = movie.title!
        movieRank = String(movie.pk!)
//        advanceRate = String(movie.reservationScore!)
    }
}
