//
//  MovieCollectionViewCell.swift
//  CGVProject
//
//  Created by Wi on 28/11/2018.
//  Copyright © 2018 Wi. All rights reserved.
//

import UIKit



class MovieCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var moviePoster: UIImageView!
    
    @IBOutlet weak var movieName: UILabel!
    @IBOutlet weak var movieRank: UILabel!
    @IBOutlet weak var advanceRate: UILabel!
    @IBOutlet weak var bookNow: UIButton!
    
    var model: MovieCollectionViewCellModel! {
        didSet {
//            moviePoster.image = model.moviePosterImage!
            movieName.text = model.movieName
            movieRank.text = model.movieRank
            advanceRate.text = model.advanceRate
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        bookNow.layer.borderColor = UIColor.lightGray.cgColor
        bookNow.layer.borderWidth = 1
        bookNow.layer.cornerRadius = 15
        moviePoster.isUserInteractionEnabled = true
        moviePoster.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(moviePosterTap)))
        
    }
    
    @objc func moviePosterTap(_ sender: UIGestureRecognizer){
        MainViewController.singleton.showMovieDetailPage()
    }
    @IBAction func bookBtnDidTap(_ sender: UIButton) {
        MainViewController.singleton.showBookPage()
    }
    
    

    
}
