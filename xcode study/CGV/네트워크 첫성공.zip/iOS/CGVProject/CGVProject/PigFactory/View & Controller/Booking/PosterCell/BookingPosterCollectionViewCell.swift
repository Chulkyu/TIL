//
//  InsideCollectionViewCell.swift
//  CGVProject
//
//  Created by PigFactory on 26/11/2018.
//  Copyright © 2018 PigFactory. All rights reserved.
//

import UIKit

class BookingPosterCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var bookingPosterView: UIImageView!
    
}
