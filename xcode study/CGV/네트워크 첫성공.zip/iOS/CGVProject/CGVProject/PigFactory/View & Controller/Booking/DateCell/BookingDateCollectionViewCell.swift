//
//  BookingDate.swift
//  CGVProject
//
//  Created by PigFactory on 27/11/2018.
//  Copyright © 2018 PigFactory. All rights reserved.
//

import UIKit

class BookingDateCollectionViewCell: UICollectionViewCell {
    
}


