//
//  CollectionViewCell.swift
//  CGVProject
//
//  Created by PigFactory on 26/11/2018.
//  Copyright © 2018 PigFactory. All rights reserved.
//

import UIKit

class MoviePosterCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var posterView: UIImageView!
}
