//
//  MovieInfo.swift
//  CGVProject
//
//  Created by PigFactory on 02/12/2018.
//  Copyright © 2018 PigFactory. All rights reserved.
//

import Foundation

class MovieInfo {
    var title = ["hoho", "kkkkkkkkkkkkkkkkk", "3", "4","5","6"]
    var runningTime = "13:00 ~ 14:00"
}

/*
class MovieInfo {
    var director: String
    var actor: String
    var genre: String
    var openDate: String
    var runningTime: String
    
    init(director: String, actor: String, genre: String, openDate: String, runningTime: String) {
        self.director = director
        self.actor = actor
        self.genre = genre
        self.openDate = openDate
        self.runningTime = runningTime
    }
}
*/


/*
 
 func setInfoLabel(movieInfo: MovieInfo) {
 directorLabel.text = movieInfo.director
 actorLabel.text = movieInfo.actor
 genreLabel.text = movieInfo.genre
 runningTimeLabel.text = movieInfo.runningTime
 openDateLabel.text = movieInfo.openDate
 
 }
 */
