//
//  ViewController.swift
//  UIDeviceExample
//
//  Created by giftbot on 2018. 2. 5..
//  Copyright © 2018년 giftbot. All rights reserved.
//

import UIKit

/***************************************************
 UIDevice
 - 디바이스 이름 / 모델 / 화면 방향 등
 - OS 이름 / 버전
 - 인터페이스 형식 (phone, pad, tv 등)
 - 배터리 정보
 - 근접 센서 정보
 - 멀티태스킹 지원 여부
 ***************************************************/

final class ViewController: UIViewController {
  
  @IBOutlet private weak var label: UILabel!
  let device = UIDevice.current
  
  @IBAction private func systemVersion() {
    /***************************************************
     Version: Major, Minor (public), Minor (non-public)
     ***************************************************/
    
    print("\n---------- [ System Version ] ----------\n")

  }
  
  @IBAction private func architecture() {
    print("\n---------- [ Architecture ] ----------\n")
    
//    #if (arch(i386) || arch(x86_64)) && os(iOS)
    #if targetEnvironment(simulator)
      print("Simulator")
      label.text = "Simulator"
    #else
      print("Device")
      label.text = "Device"
    #endif
    
    // 1 1 0 1 1 1 1 0 0 0   Simulator
    // 1 1 0 0 0 1 1 0 0 1   Device: iPhoneX
    print("TARGET_OS_MAC : ", TARGET_OS_MAC)
    print("TARGET_OS_IOS : ", TARGET_OS_IOS)
    print("TARGET_CPU_X86 : ", TARGET_CPU_X86)
    print("TARGET_CPU_X86_64 : ", TARGET_CPU_X86_64)
    print("TARGET_OS_SIMULATOR : ", TARGET_OS_SIMULATOR)
    print("TARGET_RT_64_BIT : ", TARGET_RT_64_BIT)
    print("TARGET_RT_LITTLE_ENDIAN :", TARGET_RT_LITTLE_ENDIAN)
    print("TARGET_RT_BIG_ENDIAN :", TARGET_RT_BIG_ENDIAN)
    print("TARGET_CPU_ARM : ", TARGET_CPU_ARM)
    print("TARGET_CPU_ARM64 : ", TARGET_CPU_ARM64)
  }
  
  @IBAction private func deviceModel() {
  }
  
  
  // MARK: - Battery
  
  @IBAction private func battery() {
    /***************************************************
     public enum UIDeviceBatteryState : Int {
       case unknown
       case unplugged // on battery, discharging
       case charging  // plugged in, less than 100%
       case full      // plugged in, at 100%
     }
     ***************************************************/

  }
  
  @IBAction private func batteryMonitoring(_ sender: UIButton) {

  }
  
  
  // MARK: - Proximity State
  
  @IBAction private func proximityMonitoring(_ sender: UIButton) {
  }
  
  
  // MARK: - Orientation Notification
  
  @IBAction private func beginOrientationNotification() {
    /***************************************************
     public enum UIDeviceOrientation : Int {
       case unknown
       case portrait        // Device oriented vertically, home button on the bottom
       case portraitUpsideDown // Device oriented vertically, home button on the top
       case landscapeLeft   // Device oriented horizontally, home button on the right
       case landscapeRight  // Device oriented horizontally, home button on the left
       case faceUp          // Device oriented flat, face up
       case faceDown        // Device oriented flat, face down
     }
     
     UIDeviceOrientation은 프로젝트 설정에서 지정한 방향과 관계없이 기기 방향 변경시마다 이에 해당하는 방향 출력
     ***************************************************/

  }
  
  @objc func orientationDidChange(_ noti: Notification) {
  }
  
  @IBAction private func endOrientationNotification() {
  }
  
  /***************************************************
   * UIInterfaceOrientation 과 UIDeviceOrientation 의 차이 주의 *
   UIApplication.shared.statusBarOrientation   - statusBar 의 위치 기준
   
   public enum UIInterfaceOrientation : Int {
     case unknown
     case portrait
     case portraitUpsideDown
     case landscapeLeft
     case landscapeRight
   }
   
   UIDeviceOrientation.landscapeRight = UIInterfaceOrientation.landscapeLeft
   UIDeviceOrientation.landscapeLeft = UIInterfaceOrientation.landscapeRight
   
   UIDeviceOrientation : 디바이스 기준
   UIInterfaceOrientation : 컨텐츠 기준
   ***************************************************/
}
